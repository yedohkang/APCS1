// Team DoReMi (Kenny Chen, Lisa Eng, Yedoh Kang)
// APCS1 -- pd5
// HW#32 -- Ye Olde Role Playing Game, Expanded
// 2016-11-21

public class Cleric extends Character{

    // instance variables

    // constructor
    public Cleric (String newName) {
        name = newName;
        hp = 155;
        strength = 90;
        defense = 40;
        attackRating = 0.4;
    }

    // methods       
	

}
