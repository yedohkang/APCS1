// Team DoReMi (Kenny Chen, Lisa Eng, Yedoh Kang)
// APCS1 -- pd5
// HW#32 -- Ye Olde Role Playing Game, Expanded
// 2016-11-21

public class Scavenger extends Character{

    // instance variables

    // constructor
    public Scavenger (String newName) {
        name = newName;
        hp = 115;
        strength = 95;
        defense = 35;
        attackRating = 0.5;
    }

    // methods       
	

}
