// Team DoReMi (Kenny Chen, Lisa Eng, Yedoh Kang)
// APCS1 -- pd5
// HW#32 -- Ye Olde Role Playing Game, Expanded
// 2016-11-21

public class Mage extends Character{

    // instance variables

    // constructor
    public Mage (String newName) {
        name = newName;
        hp = 100;
        strength = 150;
        defense = 30;
        attackRating = 0.5;
    }

    // methods       
	

}
