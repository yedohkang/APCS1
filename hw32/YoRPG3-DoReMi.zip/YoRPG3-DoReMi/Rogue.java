// Team DoReMi (Kenny Chen, Lisa Eng, Yedoh Kang)
// APCS1 -- pd5
// HW#32 -- Ye Olde Role Playing Game, Expanded
// 2016-11-21

public class Rogue extends Character{

    // instance variables

    // constructor
    public Rogue (String newName) {
        name = newName;
        hp = 105;
        strength = 90;
        defense = 35;
        attackRating = 0.6;
    }

    // methods       
	

}
